<?php
include_once 'php/constantvar.php';

/* On vérifie que l'utilisateur souhaite vider son panier */
if (isset($_POST['vider'])) {
    if ($_POST['vider']) {
        viderPanier();
    }
}

if (!empty($_POST['cat']) && !empty($_POST['ref']) && !empty($_POST['nbre'])) {
    $nbre = $_POST['nbre'];
    $indiceCat = rechercheCategorie($_POST['cat'], $fichier_cat);
    $cat_name = $fichier_cat[$indiceCat]['NAME'];
    $cat = $_POST['cat'];
    $ref = $_POST['ref'];
    if (isset($_SESSION['achats'][$cat][$ref]) && $nbre >= 0) {
        if ((float) $_SESSION['achats'][$cat][$ref] - (float) $nbre == 0) {
            $fichier_prod[$cat_name][$ref]['stock'] += $nbre;
            unset($_SESSION['achats'][$cat][$ref]);
            $newJsonProduct = json_encode($fichier_prod);
            file_put_contents('data/products.json', $newJsonProduct);
        } else {
            $fichier_prod[$cat_name][$ref]['stock'] -= $nbre - $_SESSION['achats'][$cat][$ref];
            $_SESSION['achats'][$cat][$ref] = (float) $nbre;
            $newJsonProduct = json_encode($fichier_prod);
            file_put_contents('data/products.json', $newJsonProduct);
        }
    } else {
        $_SESSION['error'] = "achats";
    }
}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column min-vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php
        if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <?php afficheMenuArticles(); ?>
                <section class="col-7 text-dark py-3">
                    <!--Section heading-->
                    <h3 style="color: #506960" class="text-center text-uppercase">Votre panier</h3>
                    <hr>
                    <!--Section description-->
                    <div class="container bg-white rounded-3 py-2 d-flex" style="max-height: 80vh;overflow:auto;">
                        <div class="col-12">
                            <table style="text-align:center; ">
                                <tr>
                                    <th>Image</th>
                                    <th>Nombres</th>
                                    <th>Prix</th>
                                    <th>Prix total</th>
                                    <th>Supprimer</th>
                                </tr>
                                <tbody id="bodyTab">
                                    <?php
                                    $total = 0;
                                    $qty = 0;
                                    if (!empty($infoUser['achats'])) {
                                        foreach ($infoUser['achats'] as $cat => $tab_ref) {
                                            $indiceCat = rechercheCategorie($cat, $fichier_cat);
                                            $cat_name = $fichier_cat[$indiceCat]['NAME'];
                                            foreach ($tab_ref as $ref => $nbre) {
                                                echo '<tr id="' . $cat . '_' . $ref . '">';
                                                echo '<td style="width:25%; text-align:center;"><img width="80%" src="img/' . $fichier_prod[$cat_name][$ref]['image'] . '" /></td>';
                                                echo '<td style="width:25%;" id="' .
                                                    $cat .
                                                    '_' .
                                                    $ref .
                                                    '_nbre"><input type="number" name="quantity" min="0" max="' .
                                                    ($nbre + $fichier_prod[$cat_name][$ref]['stock']) .
                                                    '" value="' .
                                                    $nbre .
                                                    '" onchange="viderProduits(\'' .
                                                    $cat .
                                                    '\',\'' .
                                                    $ref .
                                                    '\',' .
                                                    ($nbre + $fichier_prod[$cat_name][$ref]['stock']) .
                                                    ',false)" required></td>';
                                                echo '<td style="width:25%;" id="prix_' . $cat . '_' . $ref . '">' . $fichier_prod[$cat_name][$ref]['prix'] . '</td>';
                                                echo '<td style="width:25%;" id="prixTot_' . $cat . '_' . $ref . '">' . round($nbre * (float) $fichier_prod[$cat_name][$ref]['prix'], 2) . '</td>';
                                                echo '<td><button onclick="viderProduits(\'' .
                                                    $cat .
                                                    '\',\'' .
                                                    $ref .
                                                    '\',' .
                                                    $nbre .
                                                    ',true);"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                    </svg></button></td>';
                                                echo '</tr>';
                                                $total += round($nbre * (float) $fichier_prod[$cat_name][$ref]['prix'], 2);
                                            }
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <section class="col-2 text-dark py-3 d-flex flex-column">
                    <div>
                        <h3 style="color: #506960" class="text-center text-uppercase">TOTAL : <span id="prixTotal"><?php echo $total; ?></span>&euro;
                        </h3>
                        <hr>
                        <div class="">
                            <button onclick="viderPanier();" class="w-100 btn btn-danger">VIDER</button>
                            <button onclick="payerPanier(<?php echo $infoUser['infoConnect']['etat'] == 'connected'; ?>);" class="w-100 mt-2 btn btn-success">VALIDER</button>
                            <div style="color: red;" id="alertError">
                                <?php if (isset($_GET['error']) && $_GET['error'] == "vide") {
                                    echo "Validation impossible, le panier est vide!";
                                } ?>
                            </div>
                        </div>
                    </div>
                </section>
            <?php
        }
            ?>
            </main>
            <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/ajax.js"></script>
</body>

</html>