<?php
include_once 'php/constantvar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($infoUser['user'])) {
        if (!empty($_POST['password']) && !empty($_POST['passwordConfirm'])) {
            $errors = [];
            $reponseForm = $_POST;
            if (isset($_POST['firstname'])) {
                if (!VerifInformations($_POST['firstname'], "text")) {
                    $errors['firstname'] = "Erreur!";
                }
            }
            if (isset($_POST['secondname'])) {
                if (!VerifInformations($_POST['secondname'], "text")) {
                    $errors['secondname'] = "Erreur!";
                }
            }
            if (isset($_POST['name'])) {
                if (!VerifInformations($_POST['name'], "text")) {
                    $errors['name'] = "Erreur!";
                }
            }
            if (isset($_POST['email'])) {
                if (!VerifInformations($_POST['email'], "email")) {
                    $errors['email'] = "Erreur!";
                }
            }
            if (isset($_POST['ville'])) {
                if (!VerifInformations($_POST['ville'], "text")) {
                    $errors['ville'] = "Erreur!";
                }
            }
            if (isset($_POST['number'])) {
                if (!VerifInformations($_POST['number'], "numero")) {
                    $errors['number'] = "Erreur!";
                }
            }
            if (isset($_POST['bday'])) {
                if (!VerifInformations($_POST['bday'], "date")) {
                    $errors['bday'] = "Erreur!";
                }
            }
            if ($reponseForm['password'] != $reponseForm['passwordConfirm']) {
                $errors['mdpSimilaire'] = "Erreur!";
            }
            if (empty($errors)) {
                $fichier_users = 'data/users.xml';
                $contenu_users = simplexml_load_file($fichier_users);
                $i = 0;
                foreach ($contenu_users as $user) {
                    $user = (array) $user;
                    if ($infoUser['user']['username'] == $user['username']) {
                        break;
                    }
                    $i++;
                }
                $contenu_users->user[$i]->firstname = htmlspecialchars($_POST['firstname']);
                $contenu_users->user[$i]->secondname = htmlspecialchars($_POST['secondname']);
                $contenu_users->user[$i]->email = htmlspecialchars($_POST['email']);
                $contenu_users->user[$i]->mdp = htmlspecialchars($_POST['password']);
                $contenu_users->user[$i]->bday = htmlspecialchars($_POST['bday']);
                $contenu_users->user[$i]->city = htmlspecialchars($_POST['ville']);
                $contenu_users->user[$i]->number = htmlspecialchars($_POST['number']);
                $contenu_users->asXML('data/users.xml');
                $_SESSION['user'] = (array) $contenu_users->user[$i];
                $infoUser = $_SESSION;
            }
        }
    }
}

if (!empty($infoUser['user']) && !empty($infoUser['infoConnect']['etat'])) {
    if ($infoUser['infoConnect']['etat'] == "connected") {
        if (isset($fichier_order[$infoUser['user']['username']])) {
            $tab_order = $fichier_order[$infoUser['user']['username']];
        } else {
            $tab_order = [];
        }
    }
}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
<?php include "php/squelettePHP/head.php"; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <main style="margin: 100px;" class="row site-body flex-grow-1 bg-light">
            <aside class="col-3 my-3 px-5">

                <center>
                    <h3>Mon profil</h3>
                </center>
                <hr>
                <ul class="list-group">
                    <a href="profil.php" class="d-flex list-group-item"><img src="img/utilisateurs/ogo.png" alt="Avatar Logo" width="50%" class="rounded-pill mx-auto"></a>
                    <center><a class='list-group-item' href="profil.php?page=info">Informations personnelles</a></center>
                    <center><a class='list-group-item' href="profil.php?page=achat">Mes commandes en cours</a></center>
                    <center><a class='list-group-item' href="profil.php?page=histo">Historique de commandes</a></center>
                </ul>

            </aside>
            <article class="col-9 py-2 position-relative d-flex">

                <?php if (!isset($_SESSION['infoConnect']['etat']) || $_SESSION['infoConnect']['etat'] == 'disconnected') {
                    afficheFormConnexion();
                } else {
                    if (!empty($_GET['page'])) {
                        $page = $_GET['page'];
                        if ($page == 'info') { ?>
                            <section class="offset-3 bg-white col-6 py-3 rounded-3 " style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                                <div class="container">
                                    <div class="row">
                                        <h2 class="text-uppercase text-center pb-3">Informations personnelles</h2>
                                        <div class="col-12">
                                            <div class="position-relative d-flex">
                                                <form id="perso-form" class="col-10 offset-1" name="perso-form" action="profil.php?page=info" onsubmit="return verifFormulaire('perso-form')" method="POST">
                                                    <!--Grid row-->
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="email" class="">Nom</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['firstname'] ?? '' ?></span><br>
                                                                <input type="text" id="firstname" name="firstname" class="form-control" value="<?php echo $infoUser['user']['firstname']; ?>" oninput="checkForm('firstname','text')" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="email" class="">Prénom</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['secondname'] ?? '' ?></span><br>
                                                                <input type="text" id="secondname" name="secondname" class="form-control" value="<?php echo $infoUser['user']['secondname']; ?>" oninput="checkForm('secondname','text')" required>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">

                                                        <!--Grid column-->
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="name" class="">Nom d'utilisateur</label>
                                                                <input type="text" id="name" name="name" class="form-control" value="<?php echo $infoUser['user']['username']; ?>" disabled>
                                                            </div>
                                                        </div>
                                                        <!--Grid column-->

                                                        <!--Grid column-->
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="email" class="">E-mail</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['email'] ?? '' ?></span><br>
                                                                <input type="email" id="email" name="email" class="form-control" value="<?php echo $infoUser['user']['email']; ?>" oninput="checkForm('email','email')" required>
                                                            </div>
                                                        </div>
                                                        <!--Grid column-->

                                                    </div>
                                                    <!--Grid row-->

                                                    <!--Grid row-->
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="subject" class="">Mot de passe</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['mdpSimilaire'] ?? '' ?></span><br>
                                                                <input type="password" id="password" name="password" class="form-control" value="<?php echo $infoUser['user']['mdp']; ?>" oninput="checkForm('password','text')" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="subject" class="">Confirmation mot de passe</label>
                                                                <input type="password" id="passwordConfirm" name="passwordConfirm" class="form-control" value="" oninput="checkForm('passwordConfirm','text')" required>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <!--Grid row-->
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="subject" class="">Date d'anniversaire</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['bday'] ?? '' ?></span><br>
                                                                <input type="date" id="bday" name="bday" class="form-control" value="<?php if (isset($infoUser['user']['bday'])) {
                                                                                                                                            echo $infoUser['user']['bday'];
                                                                                                                                        } ?>" oninput="checkForm('bday','date')" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="subject" class="">Ville</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['ville'] ?? '' ?></span><br>
                                                                <input type="text" id="ville" name="ville" class="form-control" value="<?php if (isset($infoUser['user']['city'])) {
                                                                                                                                            echo $infoUser['user']['city'];
                                                                                                                                        } ?>" oninput="checkForm('ville','text')" required>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="md-form mb-0">
                                                                <label for="subject" class="">Numéro de téléphone</label>
                                                                <span style='color: red; text-align:start;'><?= $errors['number'] ?? '' ?></span><br>
                                                                <input type="number" id="number" name="number" class="form-control" value="<?php if (isset($infoUser['user']['number'])) {
                                                                                                                                                echo $infoUser['user']['number'];
                                                                                                                                            } ?>" oninput="checkForm('number','number')" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--Grid row-->
                                                    <div class="text-center text-md-left mt-2 mb-2 col-4 offset-4">
                                                        <button type="submit" class="btn btn-primary">ENREGISTRER</button>
                                                    </div>
                                                    <div class="status"></div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php }
                        if ($page == 'achat') { ?>
                            <section class="offset-3 bg-white col-6 py-3 rounded-3 " style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                                <div class="container">
                                    <div class="row">
                                        <h2 class="text-uppercase text-center pb-3">Mes commandes en cours</h2>
                                        <div class="position-relative d-flex">
                                            <table class="w-100 tableCommande" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th>Référence</th>
                                                        <th>Date</th>
                                                        <th>Nombre d'articles</th>
                                                        <th>Prix</th>
                                                        <th>Etat</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($tab_order as $ref => $info) {

                                                        $total = 0;
                                                        if ($info['etat'] != 'Traité') { ?>
                                                            <tr>
                                                                <td><?php echo $ref; ?></td>
                                                                <?php foreach ($info as $keyName => $value) {
                                                                    if (is_array($value)) {
                                                                        foreach ($value as $cat => $refProd) {
                                                                            foreach ($refProd as $nbre) {
                                                                                $total += $nbre;
                                                                            }
                                                                        }
                                                                        echo "<td>" . $total . "</td>";
                                                                    } else {
                                                                ?>
                                                                        <td><?php echo $value; ?></td>
                                                            <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                            </tr>
                                                        <?php
                                                    } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php }
                        if ($page == 'histo') { ?>
                            <section class="offset-3 bg-white col-6 py-3 rounded-3 " style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                                <div class="container">
                                    <div class="row">
                                        <h2 class="text-uppercase text-center pb-3">Historique de commandes</h2>
                                        <div class="position-relative d-flex">
                                            <table class="w-100 tableCommande" style="text-align:center;">
                                                <thead>
                                                    <tr>
                                                        <th>Référence</th>
                                                        <th>Date</th>
                                                        <th>Nombre d'articles</th>
                                                        <th>Prix</th>
                                                        <th>Etat</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($tab_order as $ref => $info) {

                                                        $total = 0;
                                                        if ($info['etat'] == 'Traité') { ?>
                                                            <tr>
                                                                <td><?php echo $ref; ?></td>
                                                                <?php foreach ($info as $keyName => $value) {
                                                                    if (is_array($value)) {
                                                                        foreach ($value as $cat => $refProd) {
                                                                            foreach ($refProd as $nbre) {
                                                                                $total += $nbre;
                                                                            }
                                                                        }
                                                                        echo "<td>" . $total . "</td>";
                                                                    } else {
                                                                ?>
                                                                        <td><?php echo $value; ?></td>
                                                            <?php
                                                                    }
                                                                }
                                                            }
                                                            ?>
                                                            </tr>
                                                        <?php
                                                    } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </section>
                <?php }
                    }
                } ?>

            </article>
        </main>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/form.js"></script>
</body>

</html>