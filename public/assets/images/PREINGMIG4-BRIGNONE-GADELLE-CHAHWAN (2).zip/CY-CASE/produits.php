<?php
include_once 'php/constantvar.php';

$cat_name = "";
if (!empty(returnTab())) {
    $fichier_cat = returnTab()["categories"];
    $fichier_prod = returnTab()["produits"];
    if (isset($_GET['cat']) && isset($_GET['ref'])) {
        $cat = $_GET['cat'];
        $ref = $_GET['ref'];
        $indiceCat = rechercheCategorie($cat, $fichier_cat);
        if ($indiceCat < count($fichier_cat)) {
            $cat_name = $fichier_cat[$indiceCat]['NAME'];
            if (array_key_exists($ref, $fichier_prod[$cat_name])) {
                $products = $fichier_prod[$cat_name][$ref];
                $nbreCrepes = $products['stock'];
            } else {
                header('Location:categorie.php');
            }
        } else {
            header('Location:categorie.php');
        }
    }
} else {
    echo "<center><h1>Site inaccessible! Problème d'accessibilité fichiers data.</h1></center>";
    exit(1);
}

if (!empty($_POST['quantity'])) {
    $nbreCrepes = (int) $nbreCrepes - $_POST['quantity'];
    $fichier_prod[$cat_name][$ref]['stock'] = $nbreCrepes;
    $_SESSION['achats'][$cat][$ref] += $_POST['quantity'];
    $newJsonProduct = json_encode($fichier_prod);
    file_put_contents('data/products.json', $newJsonProduct);
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <?php afficheMenuArticles(); ?>
                <article class="col-9 py-2 position-relative">
                    <section class="offset-1 col-9 py-3 rounded-3 bg-white" style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                        <div class="container">
                            <div class="row">
                                <div class="col-5 d-flex" style="height: 55vh !important;">
                                    <img class="rounded-3 mx-auto" height="100%" width="100%" onclick="deplacer(this)" src='<?php echo "img/" . $products['image']; ?>'>
                                </div>
                                <div class="col-7 position-relative">
                                    <h2 style="color: #506960" class="text-uppercase text-center"><?php echo $products['name']; ?></h2>
                                    <p class="lead">Il reste actuellement <b id="bstock"><?php echo $products['stock']; ?></b> produits</p>
                                    <p style="text-align: justify;"><?php echo $products['description']; ?></p>
                                    <p class="lead" style="bottom: 0; left: 0.75rem; position: absolute; margin-block-end: 0;">Prix :
                                        <?php echo $products['prix']; ?> &#8364;</p>
                                    <form style="bottom: 0; right: 0.75rem; position: absolute;" method="post">
                                        <input style="height: 100%;" type="number" id="quantity" name="quantity" min="0" max="<?php echo $nbreCrepes; ?>">
                                        <button onclick="<?php echo "ajax(actualiserPanier,'" . $cat . "','" . $products['ref'] . "','" . $cat_name . "');"; ?>" type="button" class="btn btn-outline-dark">
                                            Ajouter au panier
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php
            } ?>
                </article>
            </main>
            <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/ajax.js"></script>
</body>

</html>