<?php
include_once 'php/constantvar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['password']) && !empty($_POST['passwordConfirm'])) {
        $errors = [];
        $reponseForm = $_POST;
        if (isset($_POST['username'])) {
            if (!VerifInformations($_POST['username'], "text")) {
                $errors['username'] = "Erreur!";
            }
        }
        if (isset($_POST['email'])) {
            if (!VerifInformations($_POST['email'], "email")) {
                $errors['email'] = "Erreur!";
            }
        }
        if (isset($_POST['subject'])) {
            if ($_POST['subject'] == "") {
                $errors['subject'] = "Erreur!";
            }
        }
        if (isset($_POST['message'])) {
            if ($_POST['message'] == "") {
                $errors['message'] = "Erreur!";
            }
        }
        if (!empty($errors)) {
            header('Location:contact.php');
        }
    }
}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column min-vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <?php afficheMenuArticles(); ?>
                <section class="col-6 my-3">
                    <?php if ((empty($_POST['name']) && empty($_POST['email']) && empty($_POST['subject']) && empty($_POST['message'])) || !empty($errors)) { ?>
                        <!--Section heading-->
                        <h3 style="color: #506960" class="text-center text-uppercase">Contactez-nous</h3>
                        <hr>
                        <!--Section description-->
                        <div class="bg-white container rounded-3 py-2">

                            <p class="text-center w-responsive mx-auto">Avez vous la moindre question? N'hesitez pas à nous
                                contacter directement, notre équipe se chargera de vous apporter une réponse dans les meilleurs
                                délais.</p>

                            <!--Grid column-->
                            <div class="offset-1 col-md-10 mb-md-0 mb-5">
                                <form id="contact-form" name="contact-form" action="mail.php" onsubmit="return verifFormulaire('contact-form')" method="POST">

                                    <!--Grid row-->
                                    <div class="row">

                                        <!--Grid column-->
                                        <div class="col-md-6">
                                            <div class="md-form mb-0">
                                                <label for="name" class="">Votre nom</label>
                                                <span style='color: red; text-align:start;'><?= $errors['username'] ?? '' ?></span><br>
                                                <input type="text" id="name" name="name" class="form-control" placeholder="Saisisez votre nom" <?php if (isset($infoUser['infoConnect']) && $infoUser['infoConnect']['etat'] == "connected") {
                                                                                                                                                    if (!empty($infoUser['user']) && !empty($infoUser['user']['username'])) {
                                                                                                                                                        echo "value='" . $infoUser['user']['username'] . "' readonly";
                                                                                                                                                    } else {
                                                                                                                                                        echo "value='" . ($_POST['name'] ?? '') . "' required";
                                                                                                                                                    }
                                                                                                                                                } else {
                                                                                                                                                    echo "value='" . ($_POST['name'] ?? '') . "' required";
                                                                                                                                                } ?>>
                                            </div>
                                        </div>
                                        <!--Grid column-->

                                        <!--Grid column-->
                                        <div class="col-md-6">
                                            <div class="md-form mb-0">
                                                <label for="email" class="">Votre email</label>
                                                <span style='color: red; text-align:start;'><?= $errors['email'] ?? '' ?></span><br>
                                                <input type="email" id="email" name="email" class="form-control" placeholder="nom@mail.com" <?php if (isset($infoUser['infoConnect']) && $infoUser['infoConnect']['etat'] == "connected") {
                                                                                                                                                if (!empty($infoUser['user']) && !empty($infoUser['user']['email'])) {
                                                                                                                                                    echo "value='" . $infoUser['user']['email'] . "' readonly";
                                                                                                                                                } else {
                                                                                                                                                    echo "required";
                                                                                                                                                }
                                                                                                                                            } else {
                                                                                                                                                echo "required";
                                                                                                                                            } ?>>
                                            </div>
                                        </div>
                                        <!--Grid column-->

                                    </div>
                                    <!--Grid row-->

                                    <!--Grid row-->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="md-form mb-0">
                                                <label for="subject" class="">Sujet</label>
                                                <span style='color: red; text-align:start;'><?= $errors['subject'] ?? '' ?></span><br>
                                                <input type="text" id="subject" name="subject" class="form-control" placeholder="Saisissez le sujet de votre mail" required>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Grid row-->

                                    <!--Grid row-->
                                    <div class="row">

                                        <!--Grid column-->
                                        <div class="col-md-12">

                                            <div class="md-form">
                                                <label for="message">Message</label>
                                                <span style='color: red; text-align:start;'><?= $errors['message'] ?? '' ?></span><br>
                                                <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea" placeholder="Saisissez votre message..." required></textarea>
                                            </div>

                                        </div>
                                    </div>
                                    <!--Grid row-->
                                    <div class="text-center text-md-left mt-2 mb-2 col-4 offset-4">
                                        <button type="submit" class="btn btn-primary">ENVOYER</button>
                                    </div>
                                    <div class="status"></div>
                                </form>


                                <div class="status"></div>
                            </div>
                            <!--Grid column-->

                            <!--Grid column-->

                            <!--Grid column-->

                        </div>
                    <?php } else { ?>
                        <div class="col-md-10 offset-1 mb-md-0 mb-5">
                            <form id="contact-form" name="contact-form" action="mail.php" onsubmit="return verifFormulaire('contact-form')" method="POST">

                                <!--Grid row-->
                                <div class="row">

                                    <!--Grid column-->
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="name" class="">Votre nom</label>
                                            <input type="text" id="name" name="name" class="form-control" placeholder="Saisissez votre nom" value="<?php echo $_POST['name']; ?>" readonly>
                                        </div>
                                    </div>
                                    <!--Grid column-->

                                    <!--Grid column-->
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="email" class="">Votre email</label>
                                            <input type="text" id="email" name="email" class="form-control" placeholder="nom@mail.com" value="<?php echo $_POST['email']; ?>" readonly>
                                        </div>
                                    </div>
                                    <!--Grid column-->

                                </div>
                                <!--Grid row-->

                                <!--Grid row-->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="md-form mb-0">
                                            <label for="subject" class="">Sujet</label>
                                            <input type="text" id="subject" name="subject" class="form-control" placeholder="Saisissez le sujet de votre mail" value="<?php echo $_POST['subject']; ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                                <!--Grid row-->

                                <!--Grid row-->
                                <div class="row">

                                    <!--Grid column-->
                                    <div class="col-md-12">

                                        <div class="md-form">
                                            <label for="message">Message</label>
                                            <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea" placeholder="Saisissez votre message..." readonly><?php echo $_POST['message']; ?></textarea>
                                        </div>

                                    </div>
                                </div>

                            </form>

                        </div>
                    <?php } ?>
                </section>
                <section class="col-md-3">
                    <h3 style="color: #506960" class="text-center text-uppercase my-3">Nos Coordonnées</h3>
                    <hr>
                    <div class="container bg-white py-2 rounded-3">
                        <ul class="list-unstyled mb-0">
                            <li><i class="fas fa-map-marker-alt fa-2x"></i>
                                <p>Avenue du Parc, 95000 Cergy</p>
                            </li>

                            <li><i class="fas fa-phone mt-4 fa-2x"></i>
                                <p>01 34 25 10 10</p>
                            </li>

                            <li><i class="fas fa-envelope mt-4 fa-2x"></i>
                                <p>cycase@cy-tech.fr</p>
                            </li>
                        </ul>
                    </div>
                </section>
            <?php
        }
            ?>
            </main>
            <?php include_once 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/form.js"></script>
</body>

</html>