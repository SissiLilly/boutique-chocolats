<?php
include_once 'php/constantvar.php';

if (empty($_SESSION['user']) && $infoUser['infoConnect']['etat'] != "connected") {
    header('Location:panier.php');
}

if (!empty($_SESSION['achats'])) {
    $compteur = 0;
    foreach ($_SESSION['achats'] as $achats) {
        if (empty($achats)) {
            $compteur += 1;
        }
    }
    if ($compteur == count($_SESSION['achats'])) {
        header("Location:panier.php?error=vide");
    }
} else {
    header("Location:panier.php?error=vide");
}

paiementPanier();
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]  -->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <main style="margin: 300px 0;" class="row site-body flex-grow-1">
            <article class="col-12 py-2 position-relative">
                <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
                    if ($_GET['log'] == 'true') {
                        afficheFormConnexion();
                    }
                } else {
                ?>
                    <section id="divRecapP" class="offset-1 col-10 py-3 rounded-3 bg-whitesmoke" style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                        <!--Section heading-->
                        <h2 style="color: #506960" class="h1-responsive font-weight-bold text-center my-4">Récapitulatif</h2>
                        <!--Section description-->
                        <div class="row" style="max-height: 50vh;overflow:auto;">
                            <div class="col-8 offset-2">
                                <table style="text-align:center; ">
                                    <tr>
                                        <th>Image</th>
                                        <th>Nombres</th>
                                        <th>Prix unitaire HT</th>
                                        <th>Montant HT</th>
                                        <th>Montant TVA</th>
                                        <th>Total TTC</th>
                                    </tr>
                                    <tbody id="bodyTab">
                                        <?php
                                        $total = 0;
                                        $qty = 0;
                                        if (!empty($infoUser['achats'])) {
                                            foreach ($infoUser['achats'] as $cat => $tab_ref) {
                                                $indiceCat = rechercheCategorie($cat, $fichier_cat);
                                                $cat_name = $fichier_cat[$indiceCat]['NAME'];
                                                foreach ($tab_ref as $ref => $nbre) {
                                                    echo '<tr id="' . $cat . '_' . $ref . '">';
                                                    echo '<td style="width:16%;"><img width="75%" src="img/' . $fichier_prod[$cat_name][$ref]['image'] . '" /></td>';
                                                    echo '<td style="width:16%;" id="' . $cat . '_' . $ref . '_nbre">' . $nbre . '</td>';
                                                    echo '<td style="width:16%;" id="prix_' . $cat . '_' . $ref . '">' . round($fichier_prod[$cat_name][$ref]['prix'] * 0.8, 2) . ' &#8364;</td>';
                                                    echo '<td style="width:16%;" id="prixTot_' . $cat . '_' . $ref . '">' . $nbre * round((float) $fichier_prod[$cat_name][$ref]['prix'] * 0.8, 2) . ' &#8364;</td>';
                                                    echo '<td style="width:16%;">' . round($nbre * $fichier_prod[$cat_name][$ref]['prix'] * 0.2, 2) . ' &#8364;</td>';
                                                    echo '<td style="width:16%;">' . round($nbre * $fichier_prod[$cat_name][$ref]['prix'], 2) . ' &#8364;</td>';
                                                    echo '</tr>';
                                                    $total += round($nbre * (float) $fichier_prod[$cat_name][$ref]['prix'], 2);
                                                    $_SESSION['totalPrix'] = round($total, 2);
                                                }
                                            }
                                        }
                                        ?>
                                    </tbody>
                                    <tfooter>
                                        <tr>
                                            <td colspan="4"></td>
                                            <th>Prix total HT :</th>
                                            <td><?php echo round($total * 0.8, 2); ?> &#8364;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="4"></td>
                                            <th>TVA :</th>
                                            <td><?php echo round($total * 0.2, 2); ?> &#8364;</td>
                                        </tr>
                                        <tr>
                                            <td colspan="4"></td>
                                            <th>Prix total TTC :</th>
                                            <td><?php echo round($total, 2); ?> &#8364;</td>
                                        </tr>
                                    </tfooter>
                                </table>
                                <div class="d-flex mt-3">
                                    <button onclick="validPanier()" class="w-50 btn btn-success m-auto">
                                        Valider
                                    </button>
                                </div>
                            </div>
                        </div>
                    </section>
                <?php
                } ?>
            </article>
        </main>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/ajax.js"></script>
</body>

</html>