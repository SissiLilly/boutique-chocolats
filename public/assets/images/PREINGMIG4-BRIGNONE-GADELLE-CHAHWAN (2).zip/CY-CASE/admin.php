<?php
include_once 'php/constantvar.php';

if (!empty($_POST['codeCat']) && !empty($_POST['nameCat'])) {
    createCategorie();
}

if (!empty($_POST['suppr']) && !empty($_POST['catSuppr'])) {
    $fichiers = deleteCategorie();
    $fichier_cat = $fichiers['categories'];
    $fichier_prod = $fichiers['produits'];
    unset($fichiers);
}

if (!empty($_POST['supprUser']) && !empty($_POST['username'])) {
    $fichier_users = deleteUser();
}

if (!empty($_POST['etat']) && !empty($_POST['owner']) && !empty($_POST['code'])) {
    changeEtatCommand();
}

if (empty($infoUser['user']['rang']) || $infoUser['user']['rang'] != "Admin") {
    header("Location:index.php");
}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<head>
    <style>
        td,
        th {
            width: 16.6%;
            text-align: center !important;
        }

        tbody tr:hover {
            cursor: pointer;
            background-color: aqua;
        }
    </style>
</head>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <main class="row site-body flex-grow-1 mt-5 mb-5" style="height: 300vh;">
            <aside class="col-3 py-3">
                <h3 class="text-uppercase text-center">Administrateur</h3>
                <hr>
                <ul class="list-group">
                    <a class="list-group-item list-group-item-light" href="admin.php?page=user">Gérer utilisateurs</a>
                    <a class="list-group-item list-group-item-light" href="admin.php?page=offer">Gérer commandes</a>
                    <a class="list-group-item list-group-item-light" href="admin.php?page=prod">Gérer produits</a>
                    <a class="list-group-item list-group-item-light" href="admin.php?page=stock">Gérer stock</a>
                </ul>
            </aside>
            <article class="col-8 py-3 position-relative d-flex">
                <?php if (!isset($_SESSION['infoConnect']['etat']) || $_SESSION['infoConnect']['etat'] == 'disconnected') { ?>
                    <div class="col-6 m-auto bg-white rounded-3 text-dark d-flex flex-column" style="box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                        <div class="row">
                            <center>
                                <h2 class="h2 fw-lighter" style="text-transform: uppercase; margin-top: 0.5rem;">
                                    Identification</h2>
                                <center>
                        </div>
                        <div class="row flex-grow-1 col-10 m-auto rounded-3">
                            <form class="d-flex flex-column" method="post">
                                <div class="row flex-grow-1 p-2">
                                    <div>
                                        <label for="identifiantInput" class="form-label">Identifiant</label>
                                        <input class="form-control mb-3" type="text" id="identifiantInput" name="login">
                                    </div>
                                    <div>
                                        <label for="passwordInput" class="form-label">Code secret</label>
                                        <input class="form-control mb-3" type="password" id="passwordInput" name='password'>

                                    </div>
                                </div>
                                <div class="row mt-auto ms-auto me-auto w-75 mb-2">
                                    <input value="Envoyer" type="submit" id="btnSubmit" class="w-100 btn btn-outline-dark">
                                </div>
                            </form>
                        </div>
                        <div class="row">
                            <center>
                                <p style="margin-block-start: 1em">Vous n'êtes pas membre? <a href="admin.php">Inscrivez-vous</a></p>
                            </center>
                        </div>
                    </div>
                    <?php } else {
                    if (!empty($_GET['page'])) {
                        $page = $_GET['page'];
                        if ($page == 'user') { ?>
                            <section class="col-9">
                                <h3 class="text-uppercase text-center">Informations utilisateurs</h3>
                                <hr>
                                <div class="container py-3 rounded-3 bg-white">
                                    <div class="row">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Nom</th>
                                                    <th>Prénom</th>
                                                    <th>Username</th>
                                                    <th>Email</th>
                                                    <th>Numéro de téléphone</th>
                                                    <th>Rang</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $fichier_users = 'data/users.xml';
                                                $contenu_users = simplexml_load_file($fichier_users);
                                                foreach ($contenu_users as $user) {
                                                    $user = (array) $user; ?>
                                                    <tr onclick="<?php if (isset($user['username'])) {
                                                                        echo 'document.location.href=\'admin.php?page=user&username=' . $user['username'] . '\'';
                                                                    } ?>">
                                                        <td><?php if (isset($user['firstname'])) {
                                                                echo $user['firstname'];
                                                            } ?></td>
                                                        <td><?php if (isset($user['secondname'])) {
                                                                echo $user['secondname'];
                                                            } ?></td>
                                                        <td><?php if (isset($user['username'])) {
                                                                echo $user['username'];
                                                            } ?></td>
                                                        <td><?php if (isset($user['email'])) {
                                                                echo $user['email'];
                                                            } ?></td>
                                                        <td><?php if (isset($user['number'])) {
                                                                echo $user['number'];
                                                            } ?></td>
                                                        <td><?php if (isset($user['rang'])) {
                                                                echo $user['rang'];
                                                            } ?></td>
                                                    </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </section>
                            <section class="col-4 ps-4 ">
                                <h3 class="text-uppercase text-center">Détails Utilisateur</h3>
                                <hr>
                                <div class="container py-3 rounded-3 bg-white">
                                    <div class="row">
                                        <div id="contenuDetailsProd">
                                            <h5 class="text-uppercase pb-3">Informations générales</h5>
                                            <form id="user-crea-form" name="user-crea-form" action="admin.php?page=user" method="POST">
                                                <div class="row">
                                                    <?php
                                                    $okay = false;
                                                    if (!empty($_GET['username'])) {
                                                        $fichier_users = 'data/users.xml';
                                                        $contenu_users = simplexml_load_file($fichier_users);
                                                        $i = 0;
                                                        foreach ($contenu_users as $user) {
                                                            $user = (array) $user;
                                                            if ($_GET['username'] == $user['username']) {
                                                                break;
                                                            }
                                                            $i++;
                                                        }
                                                        $okay = $i < count($contenu_users) ? true : false;
                                                    }
                                                    ?>
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="codeCommand" class="">Nom</label>
                                                            <input type="text" id="firstname" name="firstname" class="form-control" value="<?php if ($okay) {
                                                                                                                                                echo $contenu_users->user[$i]->firstname;
                                                                                                                                            } ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="owner" class="">Prénom</label>
                                                            <input type="text" id="secondname" name="secondname" class="form-control" value="<?php if ($okay) {
                                                                                                                                                    echo $contenu_users->user[$i]->secondname;
                                                                                                                                                } ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="prixTot" class="">Login</label>
                                                            <input type="text" id="username" name="username" class="form-control" value="<?php if ($okay) {
                                                                                                                                                echo $contenu_users->user[$i]->username;
                                                                                                                                            } ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="etatCommand" class="">Mot de passe</label>
                                                            <input type="text" id="mdp" name="mdp" class="form-control" value="<?php if ($okay) {
                                                                                                                                    echo $contenu_users->user[$i]->mdp;
                                                                                                                                } ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="prixTot" class="">Email</label>
                                                            <input type="text" id="email" name="email" class="form-control" value="<?php if ($okay) {
                                                                                                                                        echo $contenu_users->user[$i]->email;
                                                                                                                                    } ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="etatCommand" class="">Ville</label>
                                                            <input type="text" id="city" name="city" class="form-control" value="<?php if ($okay) {
                                                                                                                                        echo $contenu_users->user[$i]->city;
                                                                                                                                    } ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="prixTot" class="">Date de naissance</label>
                                                            <input type="date" id="bday" name="bday" class="form-control" value="<?php if ($okay) {
                                                                                                                                        echo $contenu_users->user[$i]->bday;
                                                                                                                                    } ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="etatCommand" class="">Numéro de téléphone</label>
                                                            <input type="text" id="number" name="number" class="form-control" value="<?php if ($okay) {
                                                                                                                                            echo $contenu_users->user[$i]->number;
                                                                                                                                        } ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="md-form mb-0">
                                                            <label for="rang" class="">Rang</label>
                                                            <select class="form-control" id="rang" name="rang" required>
                                                                <option value=""></option>
                                                                <option value="Admin" <?php if ($okay) {
                                                                                            if ($contenu_users->user[$i]->rang == "Admin") {
                                                                                                echo "selected";
                                                                                            }
                                                                                        } ?>>
                                                                    Admin</option>
                                                                <option value="User" <?php if ($okay) {
                                                                                            if ($contenu_users->user[$i]->rang == "User") {
                                                                                                echo "selected";
                                                                                            }
                                                                                        } ?>>
                                                                    User</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-direction-row justify-content-around pt-3">
                                                    <button class="btn btn-danger" type="submit" name="supprUser" value="true">Supprimer</button>
                                                    <button class="btn btn-primary" type="submit" name="supprUser" value="false">Enregistrer</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php } elseif ($page == 'offer') { ?>
                            <section class="col-9">
                                <h3 class="text-uppercase text-center">Informations commandes</h3>
                                <hr>
                                <div class="container rounded-3 bg-white py-3">
                                    <div class="row">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Référence</th>
                                                    <th>Owner</th>
                                                    <th>Date</th>
                                                    <th>Prix</th>
                                                    <th>Etat</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($fichier_order as $user => $ref) {
                                                    foreach ($ref as $ref => $info) {
                                                        echo "<tr onclick='openCommandes(this)' id='info_" . $user . "_" . $ref . "'>";
                                                        echo '<td>' . $ref . '</td>';
                                                        echo '<td>' . $user . '</td>';
                                                        foreach ($info as $value) {
                                                            if (!is_array($value)) {
                                                                echo "<td>" . $value . "</td>";
                                                            }
                                                        }
                                                        echo "</tr>";
                                                    }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </section>
                            <section class="col-4 ps-4">
                                <h3 class="text-uppercase text-center">Détails produit</h3>
                                <hr>
                                <div class="container py-2 bg-white">
                                    <div class="row">
                                        <div id="contenuDetailsProd">
                                            <h5 class="text-uppercase pb-3">Informations générales</h5>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="codeCommand" class="">Code commande</label>
                                                        <input type="text" id="codeCommand" name="codeCommand" class="form-control" disabled>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="owner" class="">Acheteur</label>
                                                        <input type="text" id="owner" name="owner" class="form-control" disabled>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="prixTot" class="">Prix total</label>
                                                        <input type="text" id="prixTot" name="prixTot" class="form-control" disabled>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="etatCommand" class="">Etat</label>
                                                        <select class="form-control" id="etatCommand" name="etatCommand" required>
                                                            <option value=""></option>
                                                            <option value="Traité">Traité</option>
                                                            <option value="En cours">En cours</option>
                                                            <option value="Traitement">Traitement</option>
                                                            <option value="Annuler">Annuler</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center text-md-left mt-2 mb-2 col-4 offset-4">
                                                <button onclick="changerRang();" class="btn btn-primary">Enregistrer</button>
                                            </div>
                                            <hr>
                                            <h5 class="text-uppercase pb-3">Liste des produits</h5>
                                            <table id="table-offer-prod">
                                                <thead>
                                                    <tr>
                                                        <th>Nom</th>
                                                        <th>Référence</th>
                                                        <th>Quantité</th>
                                                        <th>Prix</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php } elseif ($page == 'prod') { ?>
                            <section class="col-4">
                                <h3 class="text-uppercase text-center">Catégories</h3>
                                <hr>
                                <ul class="list-group">
                                    <?php foreach ($fichier_cat as $cat) {
                                        echo "<a class='list-group-item' href='admin.php?page=prod&cat=" . $cat['CATEGORIE'] . "'>" . $cat['NAME'] . "</a>";
                                    } ?>
                                </ul>
                            </section>
                            <section class="col-9 ps-4">
                                <h3 class="text-uppercase text-center">Informations produits</h3>
                                <hr>
                                <div class="container bg-white rounded-3">
                                    <div class='d-flex flex-column'>
                                        <table class='mx-auto'>
                                            <thead>
                                                <th>Référence</th>
                                                <th>Nom</th>
                                                <th>Stock</th>
                                                <th>Prix</th>
                                            </thead>
                                            <tbody>
                                                <?php if (!empty($_GET['cat'])) {
                                                    $i = rechercheCategorie($_GET['cat'], $fichier_cat);
                                                    if ($i < count($fichier_cat)) {
                                                        foreach ($fichier_prod[$fichier_cat[$i]['NAME']] as $ref => $value) { ?>
                                                            <tr data-bs-toggle='modal' data-bs-target='#exampleModal' <?= "onclick='openPopUp(\"" . $ref . "\",\"" . $_GET['cat'] . "\",\"" . $fichier_cat[$i]['NAME'] . "\");'" ?>>
                                                                <td><?= $ref ?></td>
                                                                <td><?= $value['name'] ?></td>
                                                                <td><?= $value['stock'] ?></td>
                                                                <td><?= $value['prix'] ?></td>
                                                            </tr>
                                                <?php }
                                                    }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </section>
                            <!-- Modal -->
                            <!-- Par manque de temps, cette fonctionnalité n'a pas pu être terminé -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Détails produit référence</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body" id="popUpProd">
                                            <div class="d-flex row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <img id="popUp_Img" src="" alt="" width="100%">
                                                    </div>
                                                </div>
                                                <div class="col-md-6 d-flex flex-column justify-content-around">
                                                    <div class="row">
                                                        <div class="md-form mb-0">
                                                            <label for="nameCat" class="">Nom de l'article</label>
                                                            <input type="text" id="nameCat" name="nameCat" class="form-control" required>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="md-form mb-0">
                                                            <label for="nameCat" class="">Référence de l'article</label>
                                                            <input type="text" id="nameCat" name="nameCat" class="form-control" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="md-form mb-0">
                                                            <label for="nameCat" class="">Stock</label>
                                                            <input type="text" id="nameCat" name="nameCat" class="form-control" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex row mt-2">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="codeCat" class="">Catégorie</label>
                                                        <input type="text" id="codeCat" name="codeCat" class="form-control" readonly>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="nameCat" class="">Prix</label>
                                                        <input type="text" id="nameCat" name="nameCat" class="form-control" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex row">
                                                <div class="col-md-12">
                                                    <div class="md-form">
                                                        <label for="message">Description</label>
                                                        <textarea type="text" id="newDescription" name="newDescription" rows="2" class="form-control md-textarea"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn mb-2 btn-primary">Save
                                                changes</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } elseif ($page == 'stock') { ?>
                            <section class="col-4">
                                <h3 class="text-uppercase text-center">Catégories</h3>
                                <hr>
                                <div class="container bg-white rounded-3 py-2">
                                    <div class="row">
                                        <form id="cat-crea-form" name="cat-crea-form" action="admin.php?page=stock" method="POST" enctype='multipart/form-data'>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="codeCat" class="">Code catégorie</label>
                                                        <input type="text" id="codeCat" name="codeCat" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="nameCat" class="">Nom catégorie</label>
                                                        <input type="text" id="nameCat" name="nameCat" class="form-control" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="codeRef" class="">Code référence</label>
                                                        <input type="text" id="codeRef" name="codeRef" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="nameRef" class="">Nom article</label>
                                                        <input type="text" id="nameRef" name="nameRef" class="form-control" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="newPrix" class="">Prix</label>
                                                        <input type="text" id="newPrix" name="newPrix" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="newStock" class="">Stock</label>
                                                        <input type="text" id="newStock" name="newStock" class="form-control" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="md-form">
                                                        <label for="message">Description</label>
                                                        <textarea type="text" id="newDescription" name="newDescription" rows="2" class="form-control md-textarea"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="md-form mb-0">
                                                        <label for="photo" class="">Photo</label>
                                                        <input type="file" id="photo" name="photo" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center text-md-left mt-2 mb-2 col-4 offset-4">
                                                <button class="btn btn-primary" type="submit">Enregistrer</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </section>
                            <section class="col-9 ps-4">
                                <h3 class="text-uppercase text-center">Informations Catégories</h3>
                                <hr>
                                <div class="container rounded-3 bg-white py-2">
                                    <div class="row">
                                        <table>
                                            <thead>
                                                <th>Code catégorie</th>
                                                <th>Nom</th>
                                                <th>Nombre de références</th>
                                                <th>Supprimer</th>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($fichier_cat as $tab_cat) {
                                                    $i = 0;
                                                    foreach ($fichier_prod[$tab_cat['NAME']] as $ref) {
                                                        $i += 1;
                                                    }
                                                    echo "<tr id='" . $tab_cat['CATEGORIE'] . "CatL'>";
                                                    echo "<td>" . $tab_cat['CATEGORIE'] . "</td>";
                                                    echo "<td>" . $tab_cat['NAME'] . "</td>";
                                                    echo "<td>" . $i . "</td>";
                                                    echo '<td><button onclick="supprCat(\'' . $tab_cat['CATEGORIE'] . '\');"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                                        <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                                        <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                                    </svg></button></td>';
                                                    echo "</tr>";
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </section>
                        <?php } else {
                            echo "Impossible de trouver cette page.";
                        }
                    } elseif ($infoUser['infoConnect']['etat'] == "disconnected" && $_GET['log'] == 'true') {
                        afficheFormConnexion();
                    } else {
                        ?>
                        <section class="offset-1 col-10 py-3 rounded-3 bg-white" style="position: absolute; top: 50%; transform: translate(0, -50%); box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                            <div class="container">
                                <div class="row">
                                    <h2 class="text-uppercase text-center">CY CASE admin</h2>
                                    <div class="col-3">
                                        <img src="img/utilisateurs/ogo.png" alt="Avatar Logo" height="100%" width="100%" class="rounded-pill">
                                    </div>
                                    <div class="col-8 position-relative d-flex">
                                        <p class="flex-grow-1 mt-auto mb-auto">Nom d'utilisateur :
                                            <?php echo $infoUser['user']['username']; ?><br>Adresse mail :
                                            <?php echo $infoUser['user']['email']; ?><br>Mot de passe :
                                            <?php echo $infoUser['user']['mdp']; ?><br></p>
                                        <p class="flex-grow-1 mt-auto mb-auto">Téléphone :
                                            <?php if (isset($infoUser['user']['number'])) {
                                                echo $infoUser['user']['number'];
                                            } ?><br>Âge
                                            :
                                            <?php if (isset($infoUser['user']['bday'])) {
                                                echo $infoUser['user']['bday'];
                                            } ?><br>Ville
                                            : <?php if (isset($infoUser['user']['city'])) {
                                                    echo $infoUser['user']['city'];
                                                } ?><br>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </section>
                <?php
                    }
                } ?>

            </article>
        </main>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/ajax.js"></script>
    <script src="js/papaparse.js"></script>
</body>

</html>