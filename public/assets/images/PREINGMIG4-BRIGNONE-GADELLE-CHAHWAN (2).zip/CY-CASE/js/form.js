function verifFormulaire(id){
    var error = [];
    var tab_input = document.querySelectorAll('#'+id+' input');

    for(var i=0; i < tab_input.length; i++){
        if(!checkForm(tab_input[i].id, tab_input[i].type)){
            error.push(tab_input[i]);
        }
    }
    if(error.length == 0){
        return true;
    }
    else{
        error[0].focus();
        return false;
    }
}

function checkForm(id, type){
    var form= document.getElementById(id);
    var reg = "";
    switch(type){
        case "text":
            if(form.value !="" && form.value.length < 50){
                reg = new RegExp(/^[A-Za-z]'?[- a-zA-Z]+$/);
            }
            break;
        case "password":
            if(form.value != "" && form.value.length < 50){
                form.classList.remove("is-invalid");
                form.classList.add("is-valid");
                return true;
            }
            break;
        case "email":
            if(form.value !="" && form.value.length <70){
                reg = new RegExp(/^[a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1}([a-zA-Z0-9][\-_\.\+\!\#\$\%\&\'\*\/\=\?\^\`\{\|]{0,1})*[a-zA-Z0-9]@[a-zA-Z0-9][-\.]{0,1}([a-zA-Z][-\.]{0,1})*[a-zA-Z0-9]\.[a-zA-Z0-9]{1,}([\.\-]{0,1}[a-zA-Z]){0,}[a-zA-Z0-9]{0,}$/i);
            }
            break;
        case "number":
                reg = new RegExp(/^(0|\+33)[1-9]([-. ]?[0-9]{2}){4}$/);
            
            break;
        case "date":
            if(form.value.length==10){
                reg = new RegExp(/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/);
            }
            break;
        default:
            console.log('Erreur type checkForm');
    }
    if(reg != "" && reg.test(form.value)){
        form.classList.remove("is-invalid");
        form.classList.add("is-valid");
        return true;
    }else{
        form.classList.add("is-invalid");
        form.classList.remove("is-valid");
        return false;
    }
}