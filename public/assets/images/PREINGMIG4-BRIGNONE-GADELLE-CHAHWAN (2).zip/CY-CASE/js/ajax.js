function getXhr() {
    var xhr = null;
    if (window.XMLHttpRequest) // Firefox et autres
        xhr = new XMLHttpRequest();
    else if (window.ActiveXObject) { // Internet Explorer 
        try {
            xhr = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            xhr = new ActiveXObject("Microsoft.XMLHTTP");
        }
    } else { // XMLHttpRequest non supporté par le navigateur 
        alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");
        xhr = false;
    }
    return xhr
}

var liste_ref = [];

function ajax(callback, cat, ref, cat_name) {
    var xhr = getXhr();
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
        liste_ref = JSON.parse(xhr.responseText);
        callback(cat, ref, cat_name);
        }
    }
    xhr.open("POST", "../data/products.json", true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send(null);
}

function actualiserPanier(cat, ref, cat_name) {
    var xhr = getXhr();
    var qte = document.getElementById("quantity").value;
    /* Si la quantité est valide alors on envoie */
    if(qte > 0 && qte <= liste_ref[cat_name][ref].stock){
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
                document.getElementById("quantity").style.border = "1px solid green"; /* On met l'input d'achat en vert si il a bien été envoyé */
                document.getElementById("bstock").innerHTML = liste_ref[cat_name][ref].stock - qte; // On actualise le nombre d'articles encore disponible sur la page produit.php
            }
            else{ /* Sinon on met l'input en rouge */
                document.getElementById("quantity").style.border = "1px solid red";
            }
        }
        xhr.open("POST", "produits.php?cat=" + cat + "&ref=" + ref, true); /* On renvoie cat et ref pour le traitement PHP avec la méthode GET */
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        xhr.send("quantity=" + qte); // Nous envoyons à produit.php, correspondant à la page où l'utilisateur est, le nombre d'articles à ajouter au panier
    }
    else{ /* Si la qté est invalide on met l'input en rouge */
        document.getElementById("quantity").style.border = "1px solid red";
    }
}

function viderPanier() {
    var xhr = getXhr();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) { // Fonction de retour si tout s'est bien passé
            document.getElementById('bodyTab').innerHTML = ""; // On supprime les div contenant les articles du DOM 
            document.getElementById('prixTotal').innerHTML = "0"; // On remet à 0 le prix total
        }
    }
    xhr.open("POST", "panier.php", true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send("vider=true");
}

function viderProduits(cat,ref,max,bool){ // Supprime un nombre d'articles déterminer par l'utilisateur (=qty) pour l'article de catégorie cat et de référence ref
    var nbreUser = parseInt(document.querySelector('#'+cat+'_'+ref+'_nbre input').value)
    if(nbreUser <= max && nbreUser > 0 ){
        var xhr = getXhr();
        xhr.onreadystatechange = function() {
        if(xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            liste_ref = JSON.parse(xhr.responseText);
            viderProduits1(cat,ref,bool);
            }
        }
        xhr.open("POST", "../data/products.json", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        xhr.send(null);
    }
    else if(nbreUser <= 0){
        document.querySelector('#'+cat+'_'+ref+'_nbre input').value = 1; 
        viderProduits(cat,ref,max,bool);
    }
    else{
        document.querySelector('#'+cat+'_'+ref+'_nbre input').value = max; 
        viderProduits(cat,ref,max,bool);
    }
}

function viderProduits1(cat,ref,bool){
    var xhr = getXhr();
    var qty = parseInt(document.querySelector('#'+cat+'_'+ref+'_nbre input').value); /* On récupère la quantité à vider en s'assurant que ce soit un entier */
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {  // Fonction de retour si tout s'est bien passé
            if(bool){ /* Si bool = true alors la quantité est égale au nombre total d'articles */
                diffPrix = document.getElementById("prixTot_"+cat+'_'+ref).innerHTML;
                document.getElementById(cat+"_"+ref).remove(); // On enlève la div de l'article du DOM si qty = le nombre total d'articles dans le paniers
            }
            else{ /* Sinon on calcule le nombre d'article restant */
                diffPrix = document.getElementById("prixTot_"+cat+'_'+ref).innerHTML;
                document.getElementById("prixTot_"+cat+'_'+ref).innerHTML = document.getElementById("prix_"+cat+'_'+ref).innerHTML*qty;   
                diffPrix -= document.getElementById("prixTot_"+cat+'_'+ref).innerHTML;
            }
            /* On change le prix total du panier */
            document.getElementById('prixTotal').innerHTML = parseInt(document.getElementById('prixTotal').innerHTML) - parseInt(diffPrix);
        }
    }
    xhr.open("POST", "panier.php", true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send("cat="+cat+"&ref="+ref+"&nbre="+qty); // On envoie à panier.php le nombre d'articles à supprimer dans le fichier produits.json 
}

function payerPanier(bool){
    /* Si toutes les conditions sont remplies pour acheter alors on redirige sinon on affiche un message d'erreur */
    if(bool == true) window.location.href = "buyPanier.php";
    else document.getElementById('alertError').innerHTML = "Vous ne pouvez pas valider votre panier car vous n'êtes pas connecté!";
}

function validPanier(){
    var xhr = getXhr();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {  // Fonction de retour si tout s'est bien passé
            /* Si tout s'est bien passé on affiche le message de succès */
            document.getElementById('divRecapP').innerHTML = "<h2><center>Paiement accepté! Merci et à bientôt.</center></h2>"; 
        }
        else{
            document.getElementById('divRecapP').innerHTML = "<h2><center>Le paiement a échoué.</center></h2>"; 
        }
    }
    xhr.open("POST", "buyPanier.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send("payer=true"); 
}

function supprCat(cat){
    var xhr = getXhr();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {  // Fonction de retour si tout s'est bien passé
            /* On enlève visuellement la catégorie qui vient d'être supprimé */
            document.getElementById(cat+'CatL').remove();
        }
    }
    xhr.open("POST", "admin.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send("suppr=true&catSuppr="+cat); 
}

function openCommandes(arg){
    if(arg.hasChildNodes()){
        var children = arg.childNodes;
        if(children.length == 5){
            var infoArg = [];
            for (var i = 0; i < 2; i++) {
                infoArg.push(children[i].innerHTML); // Indice 0 : la référence, indice 1 : le nom d'utilisateur
            }
            /* On récupère l'ensemble des données data. On aurait pu utiliser une fonction callback afin d'alléger le code */
            var xhr = getXhr();
            xhr.onreadystatechange = function() { 
                if(xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
                    var details_commandes = JSON.parse(xhr.responseText)[infoArg[1]][infoArg[0]];

                    var xhr1 = getXhr();
                    xhr1.onreadystatechange = function(){
                        if(xhr1.readyState == 4 && (xhr1.status == 200 || xhr1.status == 0)) {
                            var details_produits = JSON.parse(xhr1.responseText);

                            var xhr2 = getXhr();
                            xhr2.onreadystatechange = function(){
                                if(xhr2.readyState == 4 && (xhr2.status == 200 || xhr2.status == 0)) {
                                    var details_categories = Papa.parse(xhr2.responseText);
                                    console.log(details_categories);
                                    /* On ajoute toutes les données lié à la commande dans les input correspondant */
                                    document.getElementById('codeCommand').value = infoArg[0];
                                    document.getElementById('owner').value = infoArg[1];
                                    document.getElementById('prixTot').value = details_commandes['total'];
                                    document.getElementById('etatCommand').value = details_commandes['etat'];
                                    document.querySelector('#table-offer-prod > tbody').innerHTML = "";
                                    for(var cat in details_commandes['produits']){
                                        var cat_name = "";
                                        for(var ligne in details_categories.data){
                                            if(details_categories.data[ligne][0] == cat){
                                                    cat_name = details_categories.data[ligne][1]; 
                                                    for(var ref in details_commandes['produits'][cat]){
                                                    var rowTab = document.createElement('tr');
                            
                                                    var colTab = document.createElement('td');
                                                    colTab.innerHTML = details_produits[cat_name][ref]['name'];
                                                    rowTab.appendChild(colTab);
                            
                                                    var colTab = document.createElement('td');
                                                    colTab.innerHTML = ref;
                                                    rowTab.appendChild(colTab);
                            
                                                    var colTab = document.createElement('td');
                                                    var qty = details_commandes['produits'][cat][ref];
                                                    colTab.innerHTML = qty;
                                                    rowTab.appendChild(colTab);
                                                    
                                                    var colTab = document.createElement('td');
                                                    colTab.innerHTML = parseInt(details_produits[cat_name][ref]['prix'])*qty;
                                                    rowTab.appendChild(colTab);
    
                                                    document.querySelector('#table-offer-prod > tbody').appendChild(rowTab);
                                                }
                                                break;
                                            }
                                        }
                                        if(cat_name == ""){
                                            document.querySelector('#table-offer-prod > tbody').innerHTML = "<td colspan='4' style='color:red;'>Catégorie "+cat+" absente dans le fichier categories.json</td>";
                                        }
                                    }
                                }
                            }
                            xhr2.open("POST", "../data/categories.csv", true);
                            xhr2.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
                            xhr2.send(null);
                        }
                    }
                    xhr1.open("POST", "../data/products.json", true);
                    xhr1.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
                    xhr1.send(null);
                }
            }
            xhr.open("POST", "../data/my_order.json", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            xhr.send(null);
        }
    }
}

function changerRang(){
    var xhr = getXhr();
    var etat = document.getElementById('etatCommand').value;
    var owner = document.getElementById('owner').value;
    var codeCommand = document.getElementById('codeCommand').value;
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {  // Fonction de retour si tout s'est bien passé
            document.getElementById('info_'+owner+'_'+codeCommand).lastChild.innerHTML = etat;
        }
    }
    xhr.open("POST", "admin.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send("etat="+etat+"&owner="+owner+"&code="+codeCommand); 
}

function openPopUp(ref, cat, cat_name){
    var xhr = getXhr();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
            var details_produits = JSON.parse(xhr.responseText)[cat_name][ref];
            var tab_Input = document.querySelectorAll('#popUpProd input');
            var tab_Info = [details_produits['name'], details_produits['ref'], details_produits['stock'], cat_name, details_produits['prix']];
            if(tab_Info.length == tab_Input.length){
                for(var i = 0; i < tab_Input.length; i++){
                    /* On met les informations correspondantes dans les bons inputs */
                    tab_Input[i].value = tab_Info[i];
                }
            }
            document.getElementById('popUp_Img').src = 'img/'+details_produits['image'];
            document.querySelector('#popUpProd textarea').value = details_produits['description'];
        }
    }
    xhr.open("POST", "../data/products.json", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    xhr.send(null);
}

function savePopUp(){
    var tab_Input = document.querySelectorAll('#popUpProd input');
    var tab_Input_value = [];
    for(var i=0; i<tab_Input.length; i++){
        alert(tab_Input[i].value);
    }
    for(var i=0; i<tab_Input_value.length; i++){
        alert(tab_Input_value[i]);
    }
    alert(tab_Input_value.length);
}