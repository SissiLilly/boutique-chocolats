<?php
include_once 'php/constantvar.php';
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column min-vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <main class="row site-body flex-grow-1 bg-whitesmoke">
            <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
                if ($_GET['log'] == 'true') {
                    afficheFormConnexion();
                }
            } else {
            ?>
                <section class="col-6 m-auto bg-whitesmoke rounded-3 text-dark d-flex flex-column mt-5 mb-5" style="box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                    <!--Section heading-->
                    <h2 class="h1-responsive font-weight-bold text-center my-4">Mail contact</h2>
                    <!--Section description-->
                    <p class="text-center w-responsive mx-auto">Voici le mail envoyé :</p>

                    <div class="row">
                        <?php if (!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['subject']) && !empty($_POST['message'])) { ?>
                            <!--Grid column-->
                            <div class="col-md-10 offset-1 mb-md-0 mb-5">
                                <form id="contact-form" name="contact-form" action="contact.php" method="POST">

                                    <!--Grid row-->
                                    <div class="row">

                                        <!--Grid column-->
                                        <div class="col-md-6">
                                            <div class="md-form mb-0">
                                                <label for="name" class="">Votre nom</label>
                                                <input type="text" id="name" name="name" class="form-control" placeholder="Entrez votre nom" value="<?php echo $_POST['name']; ?>" readonly>
                                            </div>
                                        </div>
                                        <!--Grid column-->

                                        <!--Grid column-->
                                        <div class="col-md-6">
                                            <div class="md-form mb-0">
                                                <label for="email" class="">Votre email</label>
                                                <input type="text" id="email" name="email" class="form-control" placeholder="monmail@monsite.org" value="<?php echo $_POST['email']; ?>" readonly>
                                            </div>
                                        </div>
                                        <!--Grid column-->

                                    </div>
                                    <!--Grid row-->

                                    <!--Grid row-->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="md-form mb-0">
                                                <label for="subject" class="">Sujet</label>
                                                <input type="text" id="subject" name="subject" class="form-control" placeholder="Entrez le sujet..." value="<?php echo $_POST['subject']; ?>" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Grid row-->

                                    <!--Grid row-->
                                    <div class="row">

                                        <!--Grid column-->
                                        <div class="col-md-12">

                                            <div class="md-form mb-4">
                                                <label for="message">Message</label>
                                                <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea" placeholder="Ecrivez ici votre message..." readonly><?php echo $_POST['message']; ?></textarea>
                                            </div>

                                        </div>
                                    </div>

                                </form>

                            </div>
                            <!--Grid column-->

                            <!--Grid column-->

                            <!--Grid column-->
                        <?php } else { ?>
                            <p style="color: red;">Il semblerait qu'il y ait une erreur dans l'envoie du mail. Vérifiez bien que
                                vous avez bien envoyer votre mail depuis la page contact.</p>
                        <?php } ?>
                    </div>
                </section>
            <?php
            } ?>
        </main>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
</body>

</html>