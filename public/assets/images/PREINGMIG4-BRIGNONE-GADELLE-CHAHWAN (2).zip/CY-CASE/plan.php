<?php include_once 'php/constantvar.php'; ?>
<!DOCTYPE html>
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <article style="margin: 50px 0;">
                    <center>
                        <img src="img/plan.png">
                    </center>
                </article>
            </main>
        <?php
        } ?>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
</body>

</html>