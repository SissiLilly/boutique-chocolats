<?php
include_once 'php/constantvar.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['password']) && !empty($_POST['passwordConfirm'])) {
        $errors = [];
        $reponseForm = $_POST;
        if (isset($_POST['firstname'])) {
            if (!VerifInformations($_POST['firstname'], "text")) {
                $errors['firstname'] = "Erreur!";
            }
        }
        if (isset($_POST['secondname'])) {
            if (!VerifInformations($_POST['secondname'], "text")) {
                $errors['secondname'] = "Erreur!";
            }
        }
        if (isset($_POST['username'])) {
            if (!VerifInformations($_POST['username'], "text")) {
                $errors['username'] = "Erreur!";
            }
        }
        if (isset($_POST['email'])) {
            if (!VerifInformations($_POST['email'], "email")) {
                $errors['email'] = "Erreur!";
            }
        }
        if ($reponseForm['password'] != $reponseForm['passwordConfirm']) {
            $errors['mdpSimilaire'] = "Erreur!";
        }
        if (empty($errors)) {
            if ($reponseForm['password'] == $reponseForm['passwordConfirm']) {
                addUser($reponseForm);
                header('Location:index.php');
            }
        }
    }
}
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column min-vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <main class="row site-body flex-grow-1 bg-whitesmoke">
            <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
                if ($_GET['log'] == 'true') {
                    afficheFormConnexion();
                }
            } else {
            ?>
                <section class="col-6 m-auto bg-whitesmoke rounded-3 text-dark d-flex flex-column mt-5 mb-5" style="box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
                    <!--Section heading-->
                    <h2 style="color: #506960" class="h1-responsive font-weight-bold text-center my-4">Inscription</h2>

                    <div class="row">

                        <!--Grid column-->
                        <div class="col-md-10 offset-1  mb-md-0 mb-5">
                            <form id="inscription-form" name="inscription-form" action="inscription.php" onsubmit="return verifFormulaire('inscription-form')" method="POST">

                                <!--Grid row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="email" class="">Nom</label>
                                            <span style='color: red; text-align:start;'><?= $errors['firstname'] ?? '' ?></span><br>
                                            <input type="text" id="firstname" name="firstname" class="form-control" oninput="checkForm('firstname','text')" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="email" class="">Prénom</label>
                                            <span style='color: red; text-align:start;'><?= $errors['secondname'] ?? '' ?></span><br>
                                            <input type="text" id="secondname" name="secondname" class="form-control" oninput="checkForm('secondname','text')" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">

                                    <!--Grid column-->
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="name" class="">Nom d'utilisateur</label>
                                            <input type="text" id="name" name="name" class="form-control" oninput="checkForm('name','text')" required>
                                        </div>
                                    </div>
                                    <!--Grid column-->

                                    <!--Grid column-->
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="email" class="">E-mail</label>
                                            <span style='color: red; text-align:start;'><?= $errors['email'] ?? '' ?></span><br>
                                            <input type="email" id="email" name="email" class="form-control" oninput="checkForm('email','email')" required>
                                        </div>
                                    </div>
                                    <!--Grid column-->

                                </div>
                                <!--Grid row-->

                                <!--Grid row-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="subject" class="">Mot de passe</label>
                                            <span style='color: red; text-align:start;'><?= $errors['mdpSimilaire'] ?? '' ?></span><br>
                                            <input type="password" id="password" name="password" class="form-control" oninput="checkForm('password','text')" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="md-form mb-0">
                                            <label for="subject" class="">Confirmation mot de passe</label>
                                            <input type="password" id="passwordConfirm" name="passwordConfirm" class="form-control" oninput="checkForm('passwordConfirm','text')" required>
                                        </div>
                                    </div>
                                </div>
                                <!--Grid row-->

                                <div class="text-center text-md-left mt-2 mb-2 col-4 offset-4">
                                    <button type="submit" class="btn btn-primary">ENREGISTRER</button>
                                </div>
                                <div class="status"></div>
                            </form>
                        </div>
                    </div>
                </section>
            <?php
            } ?>
        </main>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
    <script src="js/form.js"></script>
</body>

</html>