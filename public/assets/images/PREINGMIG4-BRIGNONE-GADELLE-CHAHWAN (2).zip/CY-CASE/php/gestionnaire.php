<?php

function verifAdmin()
{
    $infoUser = $_SESSION;
    if (!empty($_SESSION['user']) && $infoUser['infoConnect']['etat'] == "connected" && !empty($_SESSION['achats'])) {
    } else {
        header('Location:' . $_SERVER['SCRIPT_NAME'] . '?log=true');
    }
}


/* ----------------- FONCTION POUR FICHIER CSV --------------*/


function assoc_getcsv($csv_path)
{
    $r = array_map('str_getcsv', file($csv_path));
    foreach ($r as $k => $d) {
        $r[$k] = array_combine($r[0], $r[$k]);
    }
    return array_values(array_slice($r, 1));
}


/*----------------------------- FONCTIONS LIES AUX CATEGORIES --------------------------- */


function rechercheCategorie($elem, $tab_cat)
{
    $i = 0;
    foreach ($tab_cat as $tab_cat) {
        if (in_array($elem, $tab_cat)) {
            /* Stop de chercher si il y a correspondance avec le nom de la categorie $elem */
            break;
        }
        $i++;
    }
    /* Retourne l'indice du tableau correspondant à la catégorie $elem */
    return $i;
}

function createCategorie()
{
    /* Types de fichiers acceptés */
    $allowed = ["jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png"];
    /* On récupère le nom du fichier envoyer par l'utilisateur */
    $filename = $_FILES["photo"]["name"];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    /* On vérifie que l'extension est valide */
    if (array_key_exists($ext, $allowed)) {
        /* On vérifie que le dossier de la nouvelle catégorie n'existe pas */
        if (!file_exists('img/' . $_POST['nameCat'])) {
            /* On vérifie que l'image ne contient pas d'erreur */
            if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
                /* On vérifie que l'on récupère bien les fichiers data */
                if (!empty(returnTab())) {
                    /* Définition des variables */
                    global $path_cat;
                    $codeCat = htmlspecialchars($_POST['codeCat']);
                    $nameCat = htmlspecialchars($_POST['nameCat']);
                    $codeRef = htmlspecialchars($_POST['codeRef']);
                    /* On ajoute à la fin du fichier catégorie la nouvelle catégorie */
                    $fileCategorie = fopen($path_cat, "a");
                    fwrite($fileCategorie, "\n" . $codeCat . ',' . $nameCat);

                    /* On ajoute les données du nouveau produit de la nouvelle catégorie au fichier produit */
                    $fichier_prod = json_decode(file_get_contents("data/products.json"), true);
                    $fichier_prod = $fichier_prod[$nameCat][$codeRef];
                    $fichier_prod['name'] = htmlspecialchars($_POST['nameRef']);
                    $fichier_prod['description'] = htmlspecialchars($_POST['newDescription']);
                    $fichier_prod['image'] = $nameCat . '/' . $_POST['codeRef'] . '.' . $ext;
                    $fichier_prod['stock'] = (int) $_POST['newStock'];
                    $fichier_prod['prix'] = htmlspecialchars($_POST['newPrix']);
                    $fichier_prod['ref'] = htmlspecialchars($_POST['codeRef']);
                    $newJsonCommand = json_encode($fichier_prod);

                    /* On enregistre le fichier produit */
                    file_put_contents('data/products.json', $newJsonCommand);

                    /* On crée le dossier image avec le nom de la nouvelle catégorie */
                    mkdir('img/' . $nameCat);
                    $origine = $_FILES['photo']['tmp_name'];
                    $destination = 'img/' . $nameCat . '/' . $_POST['codeRef'] . '.' . $ext;

                    /* On enregistre l'image du nouveau produit */
                    move_uploaded_file($origine, $destination);
                }
            }
        }
    }
}

function deleteCategorie()
{
    /* On récupère les nom dees catégories à supprimer */
    $catSuppr = htmlspecialchars($_POST['catSuppr']);
    $suppr = htmlspecialchars($_POST['suppr']);

    global $path_cat;

    /* On vérifie qu'on récupère bien les fichiers data */
    if (!empty(returnTab())) {
        /* Définitions des variables fichieres */
        $fichier_cat = returnTab()['categories'];
        $fichier_prod = returnTab()['produits'];
        /* On vérifie que l'utilisateur souhaite bien supprimer */
        if ($suppr) {
            /* On récupère l'indice de la catégorie concernée */
            $indiceCat = rechercheCategorie($catSuppr, $fichier_cat);
            /* On vérifie qu'elle existe */
            if ($indiceCat < count($fichier_cat)) {
                $cat_name = $fichier_cat[$indiceCat]['NAME'];

                /* On supprime les données en rapport avec cette catégorie dans les fichiers produits.json et categorie.csv */
                unset($fichier_cat[$indiceCat]);
                unset($fichier_prod[$cat_name]);
                $fileCat = fopen($path_cat, "w");
                fwrite($fileCat, 'CATEGORIE,NAME' . "\n");
                foreach ($fichier_cat as $num => $tab_cat) {
                    /* Si c'est la dernière ligne alors on ne fait plus de saut de ligne */
                    if ($num == count($fichier_cat) - 1) {
                        fwrite($fileCat, $tab_cat['CATEGORIE'] . "," . $tab_cat['NAME']);
                    } else {
                        fwrite($fileCat, $tab_cat['CATEGORIE'] . "," . $tab_cat['NAME'] . "\n");
                    }
                }

                $newJsonCommand = json_encode($fichier_prod);
                file_put_contents('data/products.json', $newJsonCommand);

                /* On supprime le dossier et toutes les images correspondant à la catégorie supprimée */
                deleteTree('img/' . $cat_name);
                rmdir('img/' . $cat_name);
            }
        }
    }
    return ["categories" => $fichier_cat, "produits" => $fichier_prod];
}


/* --------------------------------------- FONCTIONS LIES AUX UTILISATEURS ----------------------------------- */


function rechercheUsers($username, $tab_users)
{
    /* Initialisation de l'indice de l'utilisateur à chercher */
    $i = 0;
    foreach ($tab_users as $user) {
        /* On passe d'un tableau objet à un tableau array */
        $user = (array) $user;
        /* On vérifie si le nom d'utilisateur correspond */
        if ($user['username'] == $username) {
            /* On arrête la boucle foreach grâce à break */
            break;
        }
        $i++;
    }
    /* On retourne l'indice correspondant à l'utilisateur. Si nous n'avons pas trouver, on renvoie le nombre d'utilisateur total */
    return $i;
}

function deleteUser()
{
    /* On modifie le type de variable supprUser en booléan */
    $supprUser = $_POST['supprUser'] == "true" ? true : false;
    $username = htmlspecialchars($_POST['username']);
    global $path_users;

    /* On vérifie qu'on arrive à accèder aux fichiers */
    if (!empty(returnTab()['users'])) {
        /* On récupère le fichier utilisateur */
        $fichier_users = returnTab()['users'];
        /* On recherche l'indice de tableau correspondant à l'utilsateur */
        $i = rechercheUsers($username, $fichier_users);
        /* On vérifie que l'on a bien trouvé l'utilisateur */
        if ($i < count($fichier_users)) {
            //ne gère pas le changement de login à corriger!
            /* Si on désire le supprime alors on libère les informations de l'utilisateur dans le fichier xml */
            if ($supprUser) {
                unset($fichier_users->user[$i]);
                $fichier_users->asXML($path_users);
            } /* Si on ne veut pas le supprimer mais simplement changer les informations alors on modifie le fichier xml avec les nouvelles informations */ else {
                $fichier_users->user[$i]->username = htmlspecialchars($_POST['username']);
                $fichier_users->user[$i]->mdp = htmlspecialchars($_POST['mdp']);
                $fichier_users->user[$i]->email = htmlspecialchars($_POST['email']);
                $fichier_users->user[$i]->firstname = htmlspecialchars($_POST['firstname']);
                $fichier_users->user[$i]->secondname = htmlspecialchars($_POST['secondname']);
                $fichier_users->user[$i]->city = htmlspecialchars($_POST['city']);
                $fichier_users->user[$i]->bday = htmlspecialchars($_POST['bday']);
                $fichier_users->user[$i]->number = htmlspecialchars($_POST['number']);
                $fichier_users->user[$i]->rang = htmlspecialchars($_POST['rang']);
                /* On enregistre le fichier utilisateur */
                $fichier_users->asXML($path_users);
            }
            /* On retourne le nouveau tableau fichier_users avec les modifications */
            return $fichier_users;
        }
    }
}


/* ----------------------------------- FONCTIONS DE CONNEXION --------------------------------------------- */


function verificationConnexion()
{
    $fichier_users = 'data/users.xml';
    $contenu_users = simplexml_load_file($fichier_users);
    if (!isset($_SESSION['infoConnect']['etat']) || $_SESSION['infoConnect']['etat'] == "disconnected") {
        if (isset($_POST['login']) && isset($_POST['password'])) {
            foreach ($contenu_users as $user) {
                $user = (array) $user;
                if ($_POST['login'] == $user['username'] && $_POST['password'] == $user['mdp']) {
                    $_SESSION['infoConnect'] = ["etat" => "connected", "date" => time()];
                    $_SESSION['user'] = $user;
                    break;
                } else {
                    if (isset($_SESSION['user'])) {
                        unset($_SESSION['user']);
                    }
                    $_SESSION['infoConnect']['etat'] = "disconnected";
                    header('Location:' . $_SERVER['SCRIPT_NAME'] . '?log=true');
                }
            }
        } else {
        }
    } elseif ($_SESSION['infoConnect']['etat'] == "connected") {
        $dureeVie = $_SESSION['time'] - $_SESSION['infoConnect']['date'];
        if ($dureeVie > 200) {
            if (isset($_SESSION['user'])) {
                unset($_SESSION['user']);
            }
            $_SESSION['infoConnect']['etat'] = "disconnected";
        }
    }
}

function userDisconnect()
{
    if (isset($_GET['etat'])) {
        if ($_GET['etat'] == 'deco') {
            if (isset($_SESSION['user'])) {
                unset($_SESSION['user']);
            }
            $_SESSION['infoConnect']['etat'] = "disconnected";
            header('Location:' . $_SERVER['SCRIPT_NAME']);
        }
    }
}

function afficheFormConnexion()
{
?>
    <div class="col-6 m-auto mt-5 mb-5 bg-light rounded-3 text-dark d-flex flex-column" style="box-shadow: 0px 0px 30px 7px rgba(0,0,0,0.5);">
        <div class=" row">
            <center>
                <h2 class="h2 fw-lighter" style="text-transform: uppercase; margin-top: 0.5rem;">Identification</h2>
                <center>
        </div>
        <div class="row flex-grow-1 col-10 m-auto rounded-3">
            <form class="d-flex flex-column" method="post" action="<?php echo $_SERVER['SCRIPT_NAME']; ?>">
                <div class="row flex-grow-1 p-2">
                    <div>
                        <label for="identifiantInput" class="form-label">Identifiant</label>
                        <input class="form-control mb-3" type="text" id="identifiantInput" name="login">
                    </div>
                    <div>
                        <label for="passwordInput" class="form-label">Code secret</label>
                        <input class="form-control mb-3" type="password" id="passwordInput" name='password'>

                    </div>
                </div>
                <div class="row mt-auto ms-auto me-auto w-75 mb-2">
                    <input value="Envoyer" type="submit" id="btnSubmit" class="w-100 btn btn-outline-dark">
                </div>
            </form>
        </div>
        <div class="row">
            <center>
                <p style="margin-block-start: 1em">Vous n'êtes pas membre? <a href="inscription.php">Inscrivez-vous</a></p>
            </center>
        </div>
    </div>
<?php
}

function addUser($reponseForm)
{
    global $path_users;
    $contenu_users = simplexml_load_file($path_users);
    $end = 1;
    foreach ($contenu_users as $user) {
        $user = (array) $user;
        if ($reponseForm['name'] == $user['username']) {
            echo "ce nom d'utilisateur existe";
            $end = 0;
            break;
        }
    }
    if ($end) {
        $contenu_user = $contenu_users->addChild('user');
        $contenu_user->addChild('username', htmlspecialchars($reponseForm['name']));
        $contenu_user->addChild('mdp', htmlspecialchars($reponseForm['password']));
        $contenu_user->addChild('email', htmlspecialchars($reponseForm['email']));
        $contenu_user->addChild('firstname', htmlspecialchars($reponseForm['firstname']));
        $contenu_user->addChild('secondname', htmlspecialchars($reponseForm['secondname']));
        $contenu_user->addChild('rang', 'User');
        $contenu_users->asXML('data/users.xml');
    }
}


/* ------------------------------------ VALIDATION DU PANIER ------------------------------------------------- */


function paiementPanier()
{
    if (!empty($_POST['payer'])) {
        $pay = htmlspecialchars($_POST['payer']);
        /* Si la personne a décidé de valider son panier définitivement */
        if ($pay) {
            /* On vérifie qu'on arrive à récupérer les données des différents fichiers data */
            if (!empty(returnTab())) {
                /* Définition des variables */
                $fichier_order = returnTab()["order"];
                $infoUser = $_SESSION;

                /* On récupère les données de la session dans un tableau data */
                $data = ['date' => date("d/m/y"), 'produits' => $infoUser['achats'], 'total' => $infoUser['totalPrix'], 'etat' => 'Traitement'];

                /* On vérifie si l'utilisateur a déjà commandé auparavant pour adapter le numéro référence de commande */
                if (!empty($fichier_order[$_SESSION['user']['username']]) && !empty($data['produits'])) {
                    /* L'utilisateur a déjà commandé. On récupère le numéro de référence de la dernière commande et on ajoute 1 au nouveau. */
                    $num = substr(array_key_last($fichier_order[$_SESSION['user']['username']]), 1);
                    $num += 1;
                    /* On crée dans le fichier commande une nouvelle référence et on y stocke les données de la commande en cours */
                    $fichier_order[$_SESSION['user']['username']]['c' . $num] = $data;
                } else {
                    /* L'utilisateur n'a jamais commandé. Son numéro de commande est donc c1 */
                    $num = 1;
                    /* On crée dans le fichier commande une nouvelle référence (en l'occurence c1) et on y stocke les données de la commande en cours */
                    $fichier_order[$_SESSION['user']['username']]['c' . $num] = $data;
                }

                /* Enfin, on sauvegarde le nouveau fichier commande avec la nouvelle commande ajouté dedans. */
                $newJsonCommand = json_encode($fichier_order);
                file_put_contents('data/my_order.json', $newJsonCommand);

                /* On supprime de la session la commande */
                unset($_SESSION['achats']);
                unset($_SESSION['totalPrix']);
            } else {
                /* Si nous n'avons pas réussi à récupérer les données des fichiers data, on renvoie un message d'erreur.  */
                echo "<center><h1>Site inaccessible! Problème d'accessibilité fichiers data.</h1></center>";
                exit(1);
            }
        }
    }
}

function viderPanier()
{
    global $fichier_cat;
    global $fichier_prod;
    foreach ($_SESSION['achats'] as $cat => $ref) {
        foreach ($ref as $name => $stock) {
            $indiceCat = rechercheCategorie($cat, $fichier_cat);
            $cat_name = $fichier_cat[$indiceCat]['NAME'];
            $fichier_prod[$cat_name][$name]['stock'] += $stock;
        }
    }
    $_SESSION['achats'] = [];
    $newJsonProduct = json_encode($fichier_prod);
    file_put_contents('data/products.json', $newJsonProduct);
}


/* --------------------------------- FONCTIONS LIES AUX COMMANDES ---------------------------------------------- */


function changeEtatCommand()
{
    /* Définition des variables */
    global $path_order;
    $etat = htmlspecialchars($_POST['etat']);
    $owner = htmlspecialchars($_POST['owner']);
    $codeCommand = htmlspecialchars($_POST['code']);

    /* On vérifie qu'on arrive à accèder aux fichiers */
    if (!empty(returnTab())) {
        $fichier_order = returnTab()['order'];
        /* On vérifie qu'il existe déjà des commandes pour l'acheteur */
        if (!empty($fichier_order[$owner])) {
            /* On vérifie que le code commande renseigné existe */
            if (!empty($fichier_order[$owner][$codeCommand])) {
                /* On change l'état par celui adéquat */
                $fichier_order[$owner][$codeCommand]['etat'] = $etat;
                /* On enregistre le nouveau fichier commande */
                $newJsonCommand = json_encode($fichier_order);
                file_put_contents($path_order, $newJsonCommand);
            }
        }
    }
}


/* -------------------------------------- SUPPRESSION DOSSIER ----------------------------------------------- */


function deleteTree($dir)
{
    foreach (glob($dir . "/*") as $element) {
        if (is_dir($element)) {
            deleteTree($element); // On rappel la fonction deleteTree
            rmdir($element); // Une fois le dossier courant vidé, on le supprime
        } else {
            // Sinon c'est un fichier, on le supprime
            unlink($element);
        }
        // On passe à l'élément suivant
    }
}


/* ------------------------------------- FICHIERS DATA EN ARRAY ------------------------------------------------*/


function returnTab()
{
    global $path_cat;
    global $path_prod;
    global $path_order;
    global $path_users;
    if (file_exists($path_cat) && file_exists($path_prod) && file_exists($path_order)) {
        return [
            "categories" => assoc_getcsv($path_cat),
            "produits" => json_decode(file_get_contents($path_prod), true),
            "order" => json_decode(file_get_contents($path_order), true),
            "users" => simplexml_load_file($path_users),
        ]; /* On retourne un tableau contenant les données du fichier csv et les donées du fichier json */
    } else {
        return [];
    }
}


/* ---------------------- Vérification des informations envoyé au serveur par un formulaire --------------------- */


function verifInformations($name, $type)
{
    switch ($type) {
        case "email":
            return filter_var($name, FILTER_VALIDATE_EMAIL);
        case "text":
            return preg_match("/^[A-Za-z]'?[- a-zA-Z]+$/", $name);
        case "date":
            return preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/", $name);
        case "submit":
            return $name == "Envoyer";
        case "numero":
            return preg_match("/^(0|\+33)[1-9]([-. ]?[0-9]{2}){4}$/", $name);
        default:
            return 0;
    }
}

function afficheMenuArticles()
{
    global $fichier_prod;
    global $fichier_cat;
?>
    <aside class="col-3 my-3">
        <h3 style="color: #506960" class="text-center text-uppercase">Nos Coques</h3>
        <hr>
        <ul class="list-group">
            <?php if (!empty($fichier_cat)) {
                foreach ($fichier_cat as $tab_cat) {
                    if (!empty($tab_cat['NAME'])) {
                        /* On vérifie que la colonne NAME existe et est non vide */
                        echo "<li style='border-color: #86a094' class='list-group-item list-group-item-light'>";
                        echo "<a style='background-color: #86a094' class='list-group-item' href='categorie.php?cat=" . $tab_cat['CATEGORIE'] . "'>" . $tab_cat['NAME'] . "</a>";
                        if (!empty($fichier_prod[$tab_cat['NAME']])) {
                            echo "<ul style='padding-inline-start: 40px;'>";
                            foreach ($fichier_prod[$tab_cat['NAME']] as $prod) {
                                echo "<li><a class='dropdown-item' href='produits.php?cat=" . $tab_cat['CATEGORIE'] . "&ref=" . $prod['ref'] . "'>" . $prod['name'] . "</a></li>";
                            }
                            echo "</ul>";
                        }
                        echo "</li>"; /* On ajoute dans le menu vertical la catégorie */
                    }
                }
            } ?>
        </ul>
    </aside>
<?php
}
?>