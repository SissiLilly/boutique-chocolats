<header style="background-color: #6e9185;" class="row site-body">
    <nav class=" offset-2 col-8 navbar navbar-expand-sm navbar-light py-1">
        <div class="container-fluid">
            <div style="padding-top: 2px; text-align: left; flex: 1; margin: 10px">
                <a href="index.php"><img src="img/cycaselogo.png" width="100px"></a>
            </div>
            <div style="display: flex; flex-direction: row; flex: 2">
                <a class="h3 fw-lighter me-3" style="margin-block-end: 0; text-transform: uppercase; text-decoration:none; color: black;" href="index.php">CYCASE</a>
            </div>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" style="background-color: #506960; border-radius: 12px 0px 0px 12px" href="index.php">Accueil</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a style="background-color: #506960" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" id="navbarScrollingDropdown">Nos Coques</a>
                        <ul class="dropdown-menu">
                            <?php if (!empty($fichier_cat)) {
                                foreach ($fichier_cat as $tab_cat) {
                                    if (!empty($tab_cat['NAME'])) {
                                        /* On vérifie que la colonne NAME existe et est non vide */
                                        echo "<li><a class='dropdown-item' href='categorie.php?cat=" . $tab_cat['CATEGORIE'] . "'>" . $tab_cat['NAME'] . "</a></li>"; /* On ajoute dans le menu vertical la catégorie */
                                    }
                                }
                            } ?>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a style="background-color: #506960; border-radius: 0px 12px 12px 0px" class="nav-link" href="contact.php">Contact</a>
                    </li>
                    <?php if (!empty($infoUser['user']['rang']) && $infoUser['user']['rang'] == "Admin") { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin.php" style="color: red !important;">Administrer</a>
                        </li>
                    <?php } ?>
                </ul>
                <div class="d-flex">
                    <?php if (isset($_SESSION['infoConnect']['etat']) && $_SESSION['infoConnect']['etat'] == 'connected') { ?>
                        <a class="btn btn-outline-dark ms-3" href="<?php echo $_SERVER['SCRIPT_NAME'] . '?etat=deco'; ?>">DECONNEXION</a>
                    <?php } else { ?>
                        <a class="btn btn-outline-dark ms-3" href="<?php echo $_SERVER['SCRIPT_NAME'] . '?log=true'; ?>">CONNEXION</a>
                    <?php } ?>
                </div>
                <div class="dropdown">
                    <a class="navbar-brand" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" id="navbarScrollingDropdown">
                        <button class="btn btn-outline-dark ms-3">PROFIL</button>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
                        <li><a class="dropdown-item" href="profil.php">Profil</a></li>
                        <li><a class="dropdown-item" href="panier.php">Panier</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item disabled">Etat :
                                <?php echo "<span class='" . ($infoUser['infoConnect']['etat'] == "connected" ? "text-success" : "text-danger") . "'>" . $infoUser['infoConnect']['etat'] . "</span>"; ?></a>
                        </li>
                    </ul>
                </div>
                <a href="panier.php" class="m-auto text-dark"><img src="img/shoppingkart.png" width="30px"></a>
            </div>
        </div>
    </nav>
</header>