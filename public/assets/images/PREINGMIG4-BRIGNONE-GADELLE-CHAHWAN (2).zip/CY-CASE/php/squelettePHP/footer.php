<footer style="background-color: #506960;" class="row site-body">
    <center>
        <br>
        <ul style="list-style-type: none; display: flex; flex-direction: row; padding-inline-start: 0; width: 75%">
            <li style="flex: 1">
                <hr>
            </li>
            <li style="flex: 1" onclick="location.href = ('plan.php')"><u>Plan du site</u></li>
            <li style="flex: 1">
                <hr>
            </li>
        </ul>
        <ul style="list-style-type: none; display: flex; flex-direction: row; padding-inline-start: 0; width: 33%">
            <li style="flex: 1">
                <p>Avenue du Parc, 95000</p>
                <p>Du Lundi au Vendredi : 10h00 - 19h30</p>
                <p>Samedi : 10h00 - 13h00</p>
            </li>
        </ul>
        <ul style="list-style-type: none; display: flex; flex-direction: row; padding-inline-start: 0; width: 33%">
            <li style="flex: 1" onclick="location.href = ('plan.php')">Nous contacter : </li>
            <li><a style="color: black" href="mailto:cycase@cy-tech.fr">cycase@cy-tech.fr</a></li>
            <li style="flex: 1">
                <p>01 34 25 10 10</p>
            </li>
        </ul>
        <br>
        <p>Réalisé par Adrian B. Andrea C. Ella G. © 2022
        </p>
    </center>
</footer>