<?php include_once "php/gestionnaire.php";

/* Lancement de la session */
session_start();
/* On stocke l'heure à laquelle l'utilisateur accède à la page pour la déconnexion automatique */
$_SESSION['time'] = time();
/* On stocke les informations de la session dans la variable infoUser */
$infoUser = $_SESSION;

/*------------ CHEMIN DES FICHIERS DATA ------------------*/

$path_cat = "data/categories.csv";
$path_prod = "data/products.json";
$path_order = "data/my_order.json";
$path_users = "data/users.xml";

/*------------------- IMPORTATION FICHIERS DATA DANS TABLEAU -----------------------*/

/* On vérifie qu'on arrive bien à récupérer les informations des fichiers datas */
if (!empty(returnTab())) {
    /* On stocke les informations des fichiers datas dans différentes variables */
    $fichier_cat = returnTab()["categories"];
    $fichier_prod = returnTab()["produits"];
    $fichier_order = returnTab()["order"];
    $fichier_users = returnTab()["users"];
    /* Si on arrive pas à récupérer l'un des fichiers data alors on retourne un message d'erreur */
} else {
    echo "<center><h1>Site inaccessible! Problème d'accessibilité fichiers data.</h1></center>";
    exit(1);
}

/* ---------------------- CONNEXION DE L'UTILISATEUR ------------------- */

/* Si tous s'est bien passé on vérifie l'état de connexion de l'utilisateur */
if (empty($_SESSION['infoConnect'])) {
    $_SESSION['infoConnect']['etat'] = 'disconnected';
}
verificationConnexion();
/* On vérifie que l'utilisateur ne souhaite pas se déconnecter */
userDisconnect();
$infoUser = $_SESSION;
