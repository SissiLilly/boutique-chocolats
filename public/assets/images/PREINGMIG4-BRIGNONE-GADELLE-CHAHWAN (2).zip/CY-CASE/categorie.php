<?php
include_once 'php/constantvar.php';

$cat_name = "";
if (isset($_GET['cat'])) {
    $cat = $_GET['cat'];
    $indiceCat = rechercheCategorie($cat, $fichier_cat);
    if ($indiceCat < count($fichier_cat)) {
        $cat_name = $fichier_cat[$indiceCat]['NAME'];
        $produits = $fichier_prod[$cat_name];
    } else {
        header('Location:categorie.php');
    }
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php
        if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <?php afficheMenuArticles(); ?>
                <article class="col-9 my-2">
                    <section class="py-2">
                        <div class="container">
                            <?php if ($cat_name != "") { ?>
                                <h3 style="color: #506960" class="text-center text-uppercase"><?php echo $cat_name; ?></h3>
                                <hr>
                            <?php } ?>
                            <div class="row d-flex overflow-auto vitrine">
                                <?php if ($cat_name != "") {
                                    foreach ($produits as $ref) {
                                        $f = "img/" . $ref['image'];
                                        $f_alt = $ref['name'];
                                        echo '<a href="produits.php?cat=' . $cat . '&ref=' . $ref['ref'] . '" class="border bg-white rounded-3 text-dark ">';
                                        echo '<div style="position: relative;">';
                                        echo '<img class="rounded-3" width="100%" onclick="deplacer(this)" src=' . $f . ' alt=' . $f_alt . '>';
                                        echo '<div class="bg-dark p-2 align-self-center text-uppercase text-light m-auto rounded-3">Shop now</div>';
                                        echo '</div>';
                                        echo '<p class="lead" style="text-align: center;">Prix : ' . $ref['prix'] . ' &#8364;<br>' . $ref['name'] . ' (ref: ' . $ref['ref'] . ')</p>';
                                        echo '</a>';
                                    }
                                } else {
                                    $i = 0;
                                    foreach ($fichier_cat as $ligne => $cat) {

                                        $i++;
                                        foreach ($fichier_prod[$cat['NAME']] as $name) {
                                            $ref_name = $name;
                                            break;
                                        }
                                ?>

                                        <section id="johndoe" class="py-5">
                                            <div class="container">
                                                <div class="row gy-4 align-items-center d-flex <?php if (fmod($i, 2) == 1) {
                                                                                                    echo "flex-row-reverse";
                                                                                                } ?>">
                                                    <div class="col-12 col-md-6">
                                                        <img src="<?php echo "../img/" . $cat['NAME'] . "/" . $ref_name['ref'] . ".jpg"; ?>" alt="" width="100%">
                                                    </div>
                                                    <div class="col-12 col-md-6">
                                                        <h1 class="fw-bold">Catégorie <?php echo $cat['NAME']; ?></h1>
                                                        <h2 class="fw-light">Dans cette catégorie vous trouverez...</h2>
                                                        <a href="categorie.php?<?php echo "cat=" . $cat['CATEGORIE']; ?>" class="btn btn-dark mt-5">Voir les <?php echo $cat['NAME']; ?></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                <?php
                                    }
                                } ?>
                            </div>
                        </div>
                    </section>
                <?php
            }
                ?>
                </article>
            </main>
            <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
</body>

</html>