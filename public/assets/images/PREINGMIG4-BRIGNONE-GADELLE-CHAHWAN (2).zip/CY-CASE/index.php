<?php include_once 'php/constantvar.php'; ?>
<!DOCTYPE html>
<html>
<?php include_once 'php/squelettePHP/head.php'; ?>

<body>
    <div class="container-fluid d-flex flex-column vh-100">
        <?php include "php/squelettePHP/header.php"; ?>
        <?php if (isset($_GET['log']) && $infoUser['infoConnect']['etat'] == "disconnected") {
            if ($_GET['log'] == 'true') {
                afficheFormConnexion();
            }
        } else {
        ?>
            <main class="row site-body flex-grow-1 bg-light">
                <article class="d-flex flex-row">
                    <?php afficheMenuArticles(); ?>
                    <div class="col-9 pe-4  ms-2 my-3">
                        <section class="bg-white">
                            <div id="acceuil">
                                <div id="row">
                                    <div id="col-2">
                                        <h1>Bienvenue sur CY CASE !</h1>
                                        <h2>Marque officielle de CY TECH engeneering</h2>
                                        <br>
                                        <p>Produits de grande qualité approuvé et testé par de chercheurs dans nos laboratoires français</p>
                                    </div>
                                    <div id="col-2">
                                        <img src="img/fondAccueil.jpeg" alt="image1">
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </article>
            </main>
        <?php
        } ?>
        <?php include 'php/squelettePHP/footer.php'; ?>
    </div>
</body>

</html>